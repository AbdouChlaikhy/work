


"""Mme , je l'ai réécrit avec ses erreurs d'origine"""


from appareil import Appareil,ExceptRef
from veloElec import VeloElec


if __name__=='__main__':
    try:
        ap1=Appareil("AA/867",400,2,3000)
        print(ap1)
        ap1.ClassEneergetique()
        vel1=VeloElec("BB/123",700,5.2,5500,4,500)
        print(vel1)
        vel1.Charger(40)
        print(vel1)
        
    except ExceptRef():
         
        print("Invalid Reference")     
F=open("app.txt","w")
F.write(ap1.__str__()+ "\n")
F.write(vel1.__str__()+ "\n") 
