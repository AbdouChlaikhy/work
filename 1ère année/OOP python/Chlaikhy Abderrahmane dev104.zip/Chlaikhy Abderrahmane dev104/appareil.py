

"""Mme , je l'ai réécrit avec ses erreurs d'origine"""

import re
class ExceptRef(Exception):
    pass


class Appareil:
    def __init__(self,ref,pui,poids,prix):
        self.setRef(ref)
        self.Puissance=pui
        self.Poids=poids
        self.Prix=prix
    def setRef(self,ref):
        r=re.compile(r"^[A-Z]{2}/[0-9]{3}$")
        if r.match(ref):
            self.ref=ref
        else:
            raise ExceptRef ()
    def __str__(self):
        return "Reference : "+self.ref+"Puissance : "+str(self.Puissance)+" Poids : "+str(self.Poids)+"Prix : "+str(self.Prix)+"Dhs"
    def ClassEneergetique(self):
        if self.Puissance>0 and self.Puissance<300:
            print("Appareil de Class A")
        elif self.Puissance>=300 and self.Puissance<=1000:
            print("Appareil de Class B")
        elif self.Puissance>1000:
            print("Appareil de Class C")
        else :
            print("Puissance Invalid")
        











